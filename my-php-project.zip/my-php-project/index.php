<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GameSpace</title>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">
                <h1>GameSpace</h1>
            </div>
            <button class="buttonlogin" onclick="location.href='login.php'">เข้าสู่ระบบ</button>
        </nav>
    </header>
    <script src="index.js"></script>
</body>
</html>
