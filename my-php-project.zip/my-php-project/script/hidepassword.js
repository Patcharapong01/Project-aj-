function togglePassword() {
    const passwordInput = document.getElementById("password");
    const toggleIcon = document.querySelector(".toggle-password");
    if (passwordInput.type === "password") {
        passwordInput.type = "text"; // แสดงรหัสผ่าน
        toggleIcon.innerHTML = ""; // เปลี่ยนไอคอน
    } else {
        passwordInput.type = "password"; // ซ่อนรหัสผ่าน
        toggleIcon.innerHTML = ""; // เปลี่ยนไอคอนกลับ
    }
}