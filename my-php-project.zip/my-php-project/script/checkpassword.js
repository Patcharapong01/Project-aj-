function validatePassword() {
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm_password").value;

    if (password !== confirmPassword) {
        alert("รหัสผ่านไม่ตรงกัน กรุณากรอกอีกรอบ"); // แสดงข้อความเมื่อรหัสผ่านไม่ตรงกัน
        return false; // ป้องกันไม่ให้ฟอร์มถูกส่ง
    }
    return true; // ส่งฟอร์มถ้ารหัสผ่านตรงกัน
}