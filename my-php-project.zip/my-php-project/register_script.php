<?php
include('condb.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert User</title>
</head>

<body>
    <div class="container">

        <?php
            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $username = $_POST['username'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    
            try {
                // ตรวจสอบว่าอีเมลซ้ำหรือไม่
                $sqlCheck = "SELECT COUNT(*) FROM user_ln WHERE email = ?";
                $stmtCheck = $conn->prepare($sqlCheck);
                $stmtCheck->bindParam(1, $email);
                $stmtCheck->execute();
                $emailExists = $stmtCheck->fetchColumn(); // ดึงค่า count จากการตรวจสอบอีเมล
                
                if ($emailExists > 0) {
                    // ถ้าอีเมลซ้ำ
                    $result = "email_exists";
                } else {
                    // เริ่มการทำธุรกรรม
                    $conn->beginTransaction();
    
                    // คำสั่ง SQL สำหรับบันทึก fname และ lname ลงตาราง info
                    $sql1 = "INSERT INTO info (fname, lname) VALUES (?, ?)";
                    $stmt1 = $conn->prepare($sql1);
                    $stmt1->bindParam(1, $fname);
                    $stmt1->bindParam(2, $lname);
                    $stmt1->execute();
    
                    // ดึง person_id ที่เพิ่งถูกสร้างขึ้น
                    $person_id = $conn->lastInsertId(); // เพิ่มบรรทัดนี้

                    // คำสั่ง SQL สำหรับบันทึก email, password ลงตาราง user_ln
                    $sql2 = "INSERT INTO user_ln (username, person_id, email, password) VALUES (?, ?, ?, ?)";
                    $stmt2 = $conn->prepare($sql2);
                    $stmt2->bindParam(1, $username);
                    $stmt2->bindParam(2, $person_id); // ใช้ $person_id
                    $stmt2->bindParam(3, $email);
                    $stmt2->bindParam(4, $passwordHash);
                    $stmt2->execute();
                    
                    // Commit
                    $conn->commit();
                    $result = "success"; // ตั้งค่า result เป็น success เมื่อสำเร็จ
                }
            } catch (Exception $e) {
                $conn->rollBack();
                $result = "error"; // ตั้งค่า result เป็น error เมื่อเกิดข้อผิดพลาด
                
                // แสดงข้อความข้อผิดพลาด
                echo "Error: " . $e->getMessage();
            }

            // SweetAlert สำหรับแสดงผลลัพธ์
            echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
            if($result == "success") {
                echo '<script>
                    setTimeout(function () {
                        Swal.fire({
                            position: "center",
                            icon: "success",
                            title: "สมัครสำเร็จ",
                            showConfirmButton: false,
                            timer: 1500
                        }).then(function () {
                            window.location = "login.php"; 
                        });
                    }, 1000);
                </script>';
            } elseif ($result === "email_exists") {
                echo '<script>
                setTimeout(function() {
                    Swal.fire({
                        position: "center",
                        icon: "error",
                        title: "อีเมลนี้ถูกใช้งานแล้ว",
                        showConfirmButton: false,
                        timer: 1500
                    }).then(function() {
                        window.location = "register.php"; 
                    });
                }, 10);
                </script>'; 
            } else {
                echo '<script>
                    setTimeout(function () {
                        Swal.fire({
                            position: "center",
                            icon: "error",
                            title: "เกิดข้อผิดพลาด",
                            showConfirmButton: false,
                            timer: 1500
                        }).then(function () {
                            window.location = "register.php"; 
                        });
                    }, 1000);
                </script>';
            }
        ?>
    </div>
</body>
</html>
