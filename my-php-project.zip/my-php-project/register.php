<?php
session_start(); // เริ่มหน้า session เพื่อใช้ในการเก็บข้อมูลระหว่างหน้าเว็บ
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/login.css">
</head>

<body>
    <div class="login-container">
        <div class="login-form">
            <h1>GameSpace Login</h1>
            <?php if(isset($_SESSION['error'])) { ?>
            <div class="alert alert-danger" role="alert">
                <?php
            echo $_SESSION['error'];
            unset($_SESSION['error']);
?>
            </div>
            <?php } ?>
            <form action="register_script.php" method="post" onsubmit="return validatePassword()">
                <input type="text" name="fname" placeholder="Frist Name" required>
                <input type="text" name="lname" placeholder="Last Name" required>
                <input type="text" name="username" placeholder="Username" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" id="password" placeholder="Password" required>
                <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm Password" required>
                <a href="#" style="text-align: right;">Forgot password?</a>
                <button type="submit">Sign In</button>
            </form>
            <p style="text-align: center; margin-top: 20px;">ฉันมีบัญชีของฉันเเล้ว 
                <a href="login.php">Sign Up</a></p>
        </div>
    </div>
    <script src="script/checkpassword.js"></script>
</body>

</html>
