<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New User</title>
    <link rel="stylesheet" href="path/to/your/css/styles.css">
</head>
<body>
<?php 
require_once '../condb.php'; 
?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <h1>Add New User</h1>
        </div>
    </section>
    <section class="content">
        <div class="card card-outline card-info">
            <div class="card-body">

                <form action="add_user_script.php" method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="fname" class="form-label">First Name</label>
                        <input type="text" class="form-control" name="fname" id="fname" required>
                    </div>
                    <div class="mb-3">
                        <label for="lname" class="form-label">Last Name</label>
                        <input type="text" class="form-control" name="lname" id="lname" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" id="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" id="username">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="text" class="form-control" name="password" id="password">
                    </div>
                    <div class="mb-3">
                        <label for="images_profile" class="form-label">Images_profile</label>
                        <input type="file" class="form-control" name="images_profile" id="images_profile" accept=".jpg,.jpeg,.png,.gif" >
                    </div>
                    <button type="submit" class="btn btn-primary">Add user</button>
                </form>
            </div>
        </div>
    </section>
</div>
</body>
</html>