    <!-- Main Sidebar Container -->
    <?php
        require_once '../condb.php';
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (isset($_SESSION['admin_login'])) {
            $user_id = $_SESSION['admin_login'];
            $sql = "SELECT info.*, user_ln.* FROM info
                    LEFT JOIN user_ln ON info.id = user_ln.person_id
                    WHERE info.id = ?"; 
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(1, $user_id);
            $stmt->execute();
            $us = $stmt->fetch(PDO::FETCH_ASSOC);
            extract($us);
            $imageURL = '../assets/dist/images_profile/'.$images_profile;
        }
        $imageURL = !empty($images_profile) ? $imageURL : '../assets/dist/images_profile/default.png';
    ?>
    
    <!-- Main Sidebar Container -->
    <aside class="main-sidebar elevation-4" id="sidebar">
        <!-- Brand Logo -->
        <a href="#" class="brand-link">
            <div style="display: flex; flex-direction: column; align-items: center;">
                <img src="<?php echo $imageURL ?>" style="width: 50%; max-width: 150px; height: auto;" class="img-circle ">
                <span class="brand-text font-weight-light"><?php echo $us['fname'] . ' ' . $us['lname']; ?></span>
            </div>
        </a>

        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                    <li class="nav-item">
                        <a href="Homepage.php" class="nav-link">
                            <i class="nav-icon fas fa-home"></i>
                            <p>หน้าหลัก</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="show_member.php" class="nav-link">
                            <i class="nav-icon fas fa-user"></i>
                            <p>ข้อมูลส่วนตัว</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="data_user.php" class="nav-link">
                            <i class="nav-icon fas fa-user"></i>
                            <p>รายชื่อบัญชี</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="nav-icon fas fa-user"></i>
                            <p>ข้อความ</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="nav-icon fas fa-user"></i>
                            <p>ประกาศอัปเดต</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="../logout.php" class="nav-link">
                            <i class="nav-icon fas fa-user"></i>
                            <p>ออกจากระบบ</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <script src="script/sidebar.js"></script>
</body>
</html>
