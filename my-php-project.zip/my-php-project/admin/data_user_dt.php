<?php
require_once '../condb.php';

// SQL Query ที่แก้ไขให้ตรงกับโครงสร้างของฐานข้อมูลของคุณ
$sql = "SELECT user_ln.email, user_ln.username, user_ln.role, info.fname, info.lname, info.images_profile
        FROM user_ln
        LEFT JOIN info ON user_ln.person_id = info.id 
        WHERE user_ln.role IN ('0', '1')";

$stmt = $conn->prepare($sql);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

$index = 1;

?>
<link rel="stylesheet" href="https://cdn.datatables.net/2.1.2/css/dataTables.dataTables.min.css">

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <h1>รายชื่อผู้ใช้งาน</h1>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <div class="card">
        <div class="card-body">
            <table class="table" id="user_ln">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Profile Image</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $us) : ?>
                        <tr>
                            <td><?php echo $index; ?></td>
                            <td><?php echo htmlspecialchars($us['fname']); ?></td>
                            <td><?php echo htmlspecialchars($us['lname']); ?></td>
                            <td><?php echo htmlspecialchars($us['email']); ?></td>
                            <td>
                                <?php 
                                // สร้างที่อยู่ไฟล์รูปภาพ
                                $imagePath = '../assets/dist/images_profile/' . htmlspecialchars($us['images_profile']);
                                // เช็คว่ามีรูปภาพหรือไม่
                                if (empty($us['images_profile']) || !file_exists($imagePath)) {
                                    $imagePath = '../assets/dist/images_profile/default.png'; // ใช้รูปภาพดีฟอลต์ถ้าไม่มีรูป
                                }
                                ?>
                                <img src="<?php echo $imagePath; ?>" 
                                     alt="Profile Image" 
                                     style="width:50px;height:50px;">
                            </td>
                        </tr>
                        <?php $index++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>
<!-- /.content-wrapper -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/2.1.2/js/dataTables.min.js"></script>
<script>
    $(document).ready(function () {
        $('#user_ln').DataTable();
    });
</script>
